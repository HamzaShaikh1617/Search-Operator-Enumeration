"""
Email Finder using Google Dorking
----------------------------------
School Project Demo

This script searches Google for email addresses associated with a given
domain, using "dork" queries (special search operators like site: and
intext:). This is a common OSINT (Open Source Intelligence) technique
used in cybersecurity recon.

IMPORTANT: Only run this against domains you own or have permission
to test (e.g. your own school project site, a practice/lab domain).
"""

import requests
import re
import time
from urllib.parse import quote

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
}


def google_dork_emails(domain, delay=5):
    """
    Runs several Google dork queries to find emails on/about a domain.
    Returns a set of unique emails found.
    """
    dorks = [
        f'site:{domain} "@{domain}"',
        f'intext:"@{domain}" filetype:pdf',
        f'intext:"@{domain}" filetype:xls',
        f'"@{domain}" -site:{domain}',
    ]

    email_pattern = re.compile(r'[a-zA-Z0-9._%+-]+@' + re.escape(domain))
    found_emails = set()

    for dork in dorks:
        print(f"[+] Running dork: {dork}")
        url = f"https://www.google.com/search?q={quote(dork)}&num=50"
        try:
            resp = requests.get(url, headers=HEADERS, timeout=10)
            if resp.status_code == 200:
                found_emails.update(email_pattern.findall(resp.text))
            else:
                print(f"    [-] Got status code {resp.status_code} "
                      f"(Google may be rate-limiting/blocking requests)")
        except requests.RequestException as e:
            print(f"    [-] Request failed: {e}")

        time.sleep(delay)  # be polite / avoid instant blocking

    return found_emails


if __name__ == "__main__":
    domain = input("Enter target domain (e.g. example.com): ").strip()
    emails = google_dork_emails(domain)

    print("\n=== Emails Found ===")
    if emails:
        for e in sorted(emails):
            print(e)
    else:
        print("No emails found. (Google frequently blocks automated "
              "requests — see README for a more reliable API-based method.)")
