# Google Dorking OSINT Toolkit (School Project)

Two simple Python scripts that demonstrate **Google dorking** — using
special search operators (like `site:`, `filetype:`, `intext:`) to find
information indexed by Google. This is a real technique used in the
cybersecurity recon phase (OSINT).

- `email_finder.py` — finds email addresses associated with a domain
- `pdf_finder.py` — finds publicly indexed PDF files on a domain

## ⚠️ Ethics / Scope Note
Only run these against:
- A domain you own, OR
- A domain you have explicit written permission to test, OR
- A practice/lab site (e.g. a site your teacher set up for the assignment)

Never run this against random real-world websites without permission.
This matches standard cybersecurity ethics (same rule taught in
Security+, CEH, and OSCP-style training).

## Requirements
- Python 3.8+
- pip

## Setup

1. Unzip this project folder.
2. Open a terminal and navigate into the folder:
   ```
   cd google_dork_project
   ```
3. (Recommended) Create a virtual environment:
   ```
   python -m venv venv
   ```
   Activate it:
   - Windows: `venv\Scripts\activate`
   - Mac/Linux: `source venv/bin/activate`
4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## How to Run

### Email Finder
```
python email_finder.py
```
You'll be prompted to enter a domain, e.g.:
```
Enter target domain (e.g. example.com): example.com
```
It will print any emails it finds.

### PDF Finder
```
python pdf_finder.py
```
Same idea — enter a domain, and it lists any publicly indexed PDF URLs
it finds.

## Why results might be empty / limited

Google actively blocks automated/scripted searches (CAPTCHAs, HTTP 429
errors), especially with repeated requests. This is expected and is a
good discussion point for your project write-up — it shows why real
tools use APIs instead of scraping.

### For a more reliable version (optional upgrade)
If you want results that don't get blocked, use the official
**Google Programmable Search Engine API** (free tier: 100 queries/day):
1. Create a Custom Search Engine: https://programmablesearchengine.google.com/
2. Get an API key: https://console.cloud.google.com/apis/credentials
3. Replace the `requests.get(...)` scraping calls with calls to:
   ```
   https://www.googleapis.com/customsearch/v1?key=YOUR_KEY&cx=YOUR_CX&q=YOUR_DORK
   ```

### Real-world tool comparison
For your report, you can also mention **theHarvester**, a well-known
open-source OSINT tool that does this same job (and more) professionally:
```
pip install theHarvester
theHarvester -d example.com -b google
```

## Files in this project
```
google_dork_project/
├── email_finder.py     # Finds emails via Google dorking
├── pdf_finder.py        # Finds PDF files via Google dorking
├── requirements.txt     # Python dependencies
└── README.md             # This file
```
