"""
PDF Finder using Google Dorking
---------------------------------
School Project Demo

This script searches Google for publicly indexed PDF files on a given
domain, using the "filetype:pdf" dork operator. This is a common OSINT
(Open Source Intelligence) technique used to discover documents that
a website has made publicly accessible (sometimes unintentionally).

IMPORTANT: Only run this against domains you own or have permission
to test (e.g. your own school project site, a practice/lab domain).
"""

import requests
import re
import time
from urllib.parse import quote

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
}


def google_dork_pdfs(domain, delay=5, pages=3):
    """
    Finds publicly indexed PDF URLs on a domain using Google dorking.
    Returns a set of unique PDF links found.
    """
    pdf_pattern = re.compile(r'https?://[^\s"\'<>]+?\.pdf')
    found_links = set()

    for page in range(pages):
        start = page * 10
        dork = f'site:{domain} filetype:pdf'
        url = f"https://www.google.com/search?q={quote(dork)}&num=10&start={start}"

        print(f"[+] Page {page + 1}: {url}")
        try:
            resp = requests.get(url, headers=HEADERS, timeout=10)
            if resp.status_code == 200:
                found_links.update(pdf_pattern.findall(resp.text))
            else:
                print(f"    [-] Got status code {resp.status_code} "
                      f"(Google may be rate-limiting/blocking requests)")
        except requests.RequestException as e:
            print(f"    [-] Request failed: {e}")

        time.sleep(delay)  # be polite / avoid instant blocking

    return found_links


if __name__ == "__main__":
    domain = input("Enter target domain (e.g. example.com): ").strip()
    pdfs = google_dork_pdfs(domain)

    print("\n=== PDF Links Found ===")
    if pdfs:
        for link in sorted(pdfs):
            print(link)
    else:
        print("No PDFs found. (Google frequently blocks automated "
              "requests — see README for a more reliable API-based method.)")
